#include "transbordador.h"
#include <control.h>
#include <string>
#include <list>


Transbordador::Transbordador()
{
    this->Inicializar();
}
void Transbordador::Inicializar(){
    Control motor1(false);
    Control motor2(false);

    Controles.push_back(motor1);
    Controles.push_back(motor2);

}

void Transbordador::Buscar(Control a){

    for(list<Control>::iterator i=Controles.begin();i!=Controles.end();++i){
        /*if (){
            cout<<"Encontrado"<<endl;
            return;
        }*/
    }
    cout<<"No encontrado"<<endl;
}
