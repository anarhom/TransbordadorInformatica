#ifndef CONTROL_H
#define CONTROL_H
#include <iostream>
#include <tripulante.h>
#include <string>

class Control
{
    public:
    string nombre;
    bool estado;
    float potencia;

public:
    Control(string,bool); //Constructor simple
    Control(string,bool,int); //Constructor compuesto
    friend class Tripulante;
    friend class Transbordador;
};

#endif // CONTROL_H
