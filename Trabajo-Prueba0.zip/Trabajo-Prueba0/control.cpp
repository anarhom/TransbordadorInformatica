#include "control.h"
#include <string>

Control::Control(string _nombre,bool _estado){
    estado=_estado;
    nombre=_nombre;

}

Control::Control(string _nombre,bool _estado,int _potencia){
    estado=_estado;
    potencia=_potencia;
    nombre=_nombre;

}
