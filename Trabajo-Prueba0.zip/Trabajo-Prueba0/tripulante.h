#ifndef TRIPULANTE_H
#define TRIPULANTE_H
#include <iostream>
#include <control.h>
#include <string>

using namespace std;

class Tripulante
{
    protected:
    string user;
    int password;

public:
    Tripulante(string, int);
    void Indentificarse(string,int,string);
};

class Copiloto:public Tripulante{
public:
    Copiloto(string,int);
    virtual void Despegar();
    virtual void Vuelo(int);
    virtual void Aterrizar();

};

class Piloto:public Copiloto{
public:
    Piloto(string,int);
    void Despegar();
    void Vuelo(int);
    void Aterrizar();

};

#endif // TRIPULANTE_H
