#include <iostream>
#include <tripulante.h>
#include <transbordador.h>
using namespace std;

int main()
{
    Tripulante t("piloto",123);
    t.Indentificarse("piloto",123,"piloto");
    Transbordador nave;
    cout<<!nave.Controles.begin()->estado<<endl;
    return 0;
}
