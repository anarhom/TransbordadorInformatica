#ifndef TRANSBORDADOR_H
#define TRANSBORDADOR_H
#include <tripulante.h>
#include <control.h>
#include <iostream>
#include <list>
#include <string>


class Transbordador
{
public:
    list<Control> Controles;
public:
    Transbordador();
    void Inicializar();
    void Buscar(Control);

};

#endif // TRANSBORDADOR_H
