#include "tripulante.h"

Tripulante::Tripulante(string _user, int _password){
    user=_user;
    password=_password;
}


void Tripulante::Indentificarse(string _usuario,int _contrasena, string tipo){
    if (tipo=="piloto"){
        Piloto piloto(_usuario,_contrasena);
    }
    else if(tipo=="copiloto"){
        Copiloto copiloto(_usuario,_contrasena);
    }
}

Copiloto::Copiloto(string _user,int _password):Tripulante(_user,_password){

}

Piloto::Piloto(string _user, int _password):Copiloto(_user,_password){

}

void Copiloto::Despegar(){
    Control *motor1;
    Control *motor2;
    motor1->estado=true;
    motor2->estado=true;

}

void Piloto::Despegar(){
    Control *motor1;
    Control *motor2;
    motor1->estado=true;
    motor2->estado=true;
}

void Copiloto::Vuelo(int _potencia){
    Control *motor1;
    Control *motor2;
    motor1->estado=true;
    motor2->estado=true;
    motor1->potencia=_potencia;
    motor2->potencia=100-_potencia;
}

void Piloto::Vuelo(int _potencia){
    Control *motor1;
    Control *motor2;
    motor1->estado=true;
    motor2->estado=true;
    motor1->potencia=_potencia;
    motor2->potencia=100-_potencia;
}

void Copiloto::Aterrizar(){
    Control *motor1;
    Control *motor2;
    motor1->estado=false;
    motor2->estado=false;
}
void Piloto::Aterrizar(){
    Control *motor1;
    Control *motor2;
    motor1->estado=false;
    motor2->estado=false;
}
