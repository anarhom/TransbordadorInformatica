#ifndef MENUPRINCIPAL_H
#define MENUPRINCIPAL_H

#include <QDialog>

namespace Ui {
class menuPrincipal;
}

class menuPrincipal : public QDialog
{
    Q_OBJECT

public:
    explicit menuPrincipal(QWidget *parent = nullptr);
    ~menuPrincipal();

private slots:
    void on_pushButton_clicked();

    void on_aterrizar_clicked();

    void on_dial_valueChanged(int value);

    void on_dial_2_valueChanged(int value);

    void on_verticalSlider_valueChanged(int value);

    void on_commandLinkButton_clicked();

private:
    Ui::menuPrincipal *ui;
};

#endif // MENUPRINCIPAL_H
