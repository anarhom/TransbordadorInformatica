#ifndef TRANSBORDADOR_H
#define TRANSBORDADOR_H
#include "control.h"
#include <iostream>
#include <list>
#include <string>

using namespace std;
class Transbordador
{
public:
    list<Control> Controles;
public:
    Transbordador();
    void Inicializar();
    list<Control>::iterator Buscar(string);

};

#endif // TRANSBORDADOR_H
