#include "tripulante.h"
using namespace std;
Tripulante::Tripulante(string _user, int _password){
    user=_user;
    password=_password;
}


void Tripulante::Indentificarse(){

}

Copiloto::Copiloto(string _user,int _password):Tripulante(_user,_password){

}

Piloto::Piloto(string _user, int _password):Copiloto(_user,_password){

}

void Copiloto::Despegar(){
    cout<<"Encender motores"<<endl;

}

void Piloto::Despegar(){
    Copiloto::Despegar();
    cout<<"A tanta potencia"<<endl;
}

void Copiloto::Vuelo(){
    cout<<"Motores a velocidad de crucero"<<endl;
}

void Piloto::Vuelo(){
    Copiloto::Vuelo();
    cout<<"acelerar"<<endl;
}

void Copiloto::Aterrizar(){
    cout<<"Motores desacelerando"<<endl;
}
void Piloto::Aterrizar(){
    Copiloto::Aterrizar();
    cout<<"Reducir la potencia"<<endl;
}
