#include "mensajeerror.h"
#include "ui_mensajeerror.h"
#include "tripulacion.h"

extern int cargo;

mensajeError::mensajeError(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::mensajeError)
{
    ui->setupUi(this);
    string sCargo=to_string(cargo);
    QString qsTexto=QString::fromUtf8(sCargo.c_str());
    ui->label_2->setText(qsTexto);

}

mensajeError::~mensajeError()
{
    delete ui;
}
