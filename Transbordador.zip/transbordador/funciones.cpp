#include "funciones.h"

funciones::funciones()
{

}
