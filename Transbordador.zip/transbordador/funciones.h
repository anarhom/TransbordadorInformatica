#ifndef FUNCIONES_H
#define FUNCIONES_H
#include <string>
#include <map>

using namespace std;

class funciones
{
public:
    funciones();
};

#endif // FUNCIONES_H
