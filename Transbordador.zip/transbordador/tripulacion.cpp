#include "tripulacion.h"
#include "transbordador.h"
tripulacion::tripulacion()
{

}
tripulacion::~tripulacion(){

}

void tripulacion::insertarTripulante(string _puesto,string user, string password){
    usuario=user;
    contrasenna=password;
    puesto=_puesto;
    if (puesto=="piloto")
        listaPilotos.insert(make_pair(usuario,contrasenna));
    if (puesto=="copiloto")
        listaCopilotos.insert(make_pair(usuario,contrasenna));
    if (puesto=="tripulante")
        listaTripulante.insert(make_pair(usuario,contrasenna));

}

int tripulacion::buscarTripulante(string user, string password){

    usuario=user;
    contrasenna=password;
    string sPassword;
    int esPiloto=0, esCopiloto=0, count1=0, count2=0;
    count1=listaPilotos.count(usuario);
    count2=listaCopilotos.count(usuario);

    if (count2 != 0) { //Si está la palabra q se busca
        sPassword=listaCopilotos.find(usuario)->second;
        if (sPassword==contrasenna)
            esCopiloto=2;
        return esCopiloto;
    }
    else if (count1 != 0){

        sPassword=listaPilotos.find(usuario)->second;
        if (sPassword==contrasenna)
            esPiloto=1;
        return esPiloto;
    }
    else
        return 3;
}

Copiloto::Copiloto(string _user,string _password):tripulacion(){
    usuario = _user;
    contrasenna = _password;
}

Piloto::Piloto(string _user, string _password):Copiloto(_user,_password){

}



void Copiloto::Vuelo(Transbordador *_nave, int a){
    _nave->Buscar("motor1")->potencia = (100-a);
    _nave->Buscar("motor2")->potencia = a;
}

void Copiloto::Despegar(Transbordador _nave){
    _nave.Buscar("motor1")->estado = 1;
    _nave.Buscar("motor2")->estado = 1;
}

void Copiloto::Aterrizar(Transbordador _nave){
    _nave.Buscar("motor1")->estado = 0;
    _nave.Buscar("motor2")->estado = 0;
}
void Piloto::Vuelo(Transbordador *_nave, int a, int b){
    _nave->Buscar("motor1")->potencia = (100-a)*b;
    _nave->Buscar("motor2")->potencia = a*b;
}
