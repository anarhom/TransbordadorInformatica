#ifndef TRIPULANTE_H
#define TRIPULANTE_H
#include <iostream>
#include "control.h"
#include <string>

using namespace std;


class Tripulante
{
    protected:
    string user;
    int password;

public:
    Tripulante(string, int);
    void Indentificarse();
};

class Copiloto:public Tripulante{
public:
    Copiloto(string,int);
    virtual void Despegar();
    virtual void Vuelo();
    virtual void Aterrizar();

};

class Piloto:public Copiloto{
public:
    Piloto(string,int);
    void Despegar();
    void Vuelo();
    void Aterrizar();

};

#endif // TRIPULANTE_H
