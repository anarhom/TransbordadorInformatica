#include "transbordador.h"
#include <string>
using namespace std;

Transbordador::Transbordador(){
    this->Inicializar();
}
void Transbordador::Inicializar(){
    Control motor1(true,"motor1",0);
    Control motor2(true,"motor2");
    //Componente motor3(true,"motor3");
    Controles.push_back(motor1);
    Controles.push_back(motor2);
    //Controles.push_back(motor3);
}

list<Control>::iterator Transbordador::Buscar(string a){

    for(list<Control>::iterator i=Controles.begin();i!=Controles.end();++i){
        if (i->nombre==a){
            return i;
        }
    }
}
