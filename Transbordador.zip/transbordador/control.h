#ifndef COMPONENTE_H
#define COMPONENTE_H
#include <iostream>
#include <string>
using namespace std;

class Control{
public:
    string nombre;
    bool estado;
    int potencia;

public:
    Control(bool,string,int); //Constructor simple
    Control(bool,string); //Constructor compuesto
    //friend class Tripulante;
    //friend class Transbordador;
};

#endif // COMPONENTE_H
