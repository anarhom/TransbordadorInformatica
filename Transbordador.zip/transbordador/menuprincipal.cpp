#include "menuprincipal.h"
#include "ui_menuprincipal.h"
#include "menutripulante.h"
#include "nuevotripulante.h"
#include "tripulacion.h"
#include "mensajeerror.h"
#include "iniciarsesion.h"
#include "transbordador.h"
#include "control.h"
extern int indicador;
Transbordador nave;
Piloto piloto("user","password");
Copiloto copiloto("user","password");
menuPrincipal::menuPrincipal(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::menuPrincipal)
{
    ui->setupUi(this);
    ui->aterrizar->setEnabled(0);
    ui->dial->setEnabled(0);
    ui->dial_2->setEnabled(0);
    ui->graphicsView->setStyleSheet("QGraphicsView{background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 rgba(159, 0, 0, 255), stop:0.728223 rgba(0, 0, 0, 255), stop:0.787456 rgba(118, 0, 0, 0));}");
    ui->graphicsView_2->setStyleSheet("QGraphicsView{background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 rgba(159, 0, 0, 255), stop:0.728223 rgba(0, 0, 0, 255), stop:0.787456 rgba(118, 0, 0, 0));}");
    ui->progressBar->setVisible(0);
    ui->verticalSlider->setEnabled(0);
}

menuPrincipal::~menuPrincipal()
{
    delete ui;
}

void menuPrincipal::on_pushButton_clicked()
{
    ui->pushButton->setEnabled(0);
    ui->progressBar->setVisible(1);
    ui->dial->setValue(50);
    ui->dial_2->setValue(50);
    for (int i=0;i<11;++i){
        ui->progressBar->setValue(i*10);
        sleep(1);
    }
    ui->progressBar->setVisible(0);
    ui->aterrizar->setEnabled(1);
    ui->graphicsView->setStyleSheet("QGraphicsView{background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 rgba(131, 0, 0, 255), stop:0.728223 rgba(255, 0, 0, 255), stop:0.792945 rgba(255, 0, 0, 148), stop:0.822086 rgba(118, 0, 0, 0));}");
    ui->graphicsView_2->setStyleSheet("QGraphicsView{background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 rgba(131, 0, 0, 255), stop:0.728223 rgba(255, 0, 0, 255), stop:0.792945 rgba(255, 0, 0, 148), stop:0.822086 rgba(118, 0, 0, 0));}");
    if (indicador==1){
        ui->dial_2->setEnabled(1);
        ui->verticalSlider->setEnabled(1);
        piloto.Despegar(nave);
    }else if (indicador==2){
        ui->dial->setEnabled(1);
        copiloto.Despegar(nave);
    }
}

void menuPrincipal::on_aterrizar_clicked()
{
    int a = ui->dial->value();
    int b = ui->dial_2->value();
    int c = ui->verticalSlider->value();
    ui->dial_2->setEnabled(0);
    ui->verticalSlider->setEnabled(0);
    ui->dial->setEnabled(0);
    ui->aterrizar->setEnabled(0);
    ui->progressBar->setVisible(1);
    for (int i=0;i<11;++i){
        ui->progressBar->setValue(i*10);
        if(indicador==1){
           ui->verticalSlider->setValue(c*(10-i)/10);
           if (b > 50){
               ui->dial_2->setValue(round(50+(b-50)*(10-i)/10));
           } else if (b < 50){
               ui->dial_2->setValue(round(50-(50-b)*(10-i)/10));
           }
           piloto.Aterrizar(nave);
        }else if (indicador==2){
            if (a > 50){
                ui->dial->setValue(round(50+(b-50)*(10-i)/10));
            } else if (a < 50){
                ui->dial->setValue(round(50-(50-b)*(10-i)/10));
            }
            copiloto.Aterrizar(nave);
        }
        sleep(1);
    }
    ui->progressBar->setVisible(0);
    ui->graphicsView->setStyleSheet("QGraphicsView{background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 rgba(159, 0, 0, 255), stop:0.728223 rgba(0, 0, 0, 255), stop:0.787456 rgba(118, 0, 0, 0));}");
    ui->graphicsView_2->setStyleSheet("QGraphicsView{background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 rgba(159, 0, 0, 255), stop:0.728223 rgba(0, 0, 0, 255), stop:0.787456 rgba(118, 0, 0, 0));}");
    ui->pushButton->setEnabled(1);


}

void menuPrincipal::on_dial_2_valueChanged(int value)
{
    piloto.Vuelo(&nave,value,ui->verticalSlider->value());
    ui->dial->setValue(value);
    ui->textBrowser->setText(QString::number(nave.Buscar("motor2")->potencia));
    ui->textBrowser_2->setText(QString::number(nave.Buscar("motor1")->potencia));
}

void menuPrincipal::on_dial_valueChanged(int value)
{
    copiloto.Vuelo(&nave,value);
    ui->dial_2->setValue(value);
    ui->textBrowser->setText(QString::number(nave.Buscar("motor2")->potencia));
    ui->textBrowser_2->setText(QString::number(nave.Buscar("motor1")->potencia));
}

void menuPrincipal::on_verticalSlider_valueChanged(int value)
{
    piloto.Vuelo(&nave,ui->dial_2->value(),value);
    ui->textBrowser->setText(QString::number(nave.Buscar("motor2")->potencia));
    ui->textBrowser_2->setText(QString::number(nave.Buscar("motor1")->potencia));
}

void menuPrincipal::on_commandLinkButton_clicked()
{
    close();
}
