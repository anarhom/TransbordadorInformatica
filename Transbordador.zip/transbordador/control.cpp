#include "control.h"
#include <string>
using namespace std;
Control::Control(bool _estado, string _nombre){
    estado = _estado;
    nombre = _nombre;
}

Control::Control(bool _estado, string _nombre, int _potencia){
    estado = _estado;
    nombre = _nombre;
    potencia = _potencia;
}
