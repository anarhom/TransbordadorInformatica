#ifndef TRIPULACION_H
#define TRIPULACION_H
#include "mainwindow.h"
#include <map>
#include "transbordador.h"

class tripulacion
{
    public:
        string usuario;
        string contrasenna;
        string puesto;
        map<string,string> listaPilotos;
        map<string,string> listaCopilotos;
        map<string,string> listaTripulante;
    public:
        tripulacion();
        ~tripulacion();
        void insertarTripulante(string,string,string);
        int buscarTripulante(string, string);
};

class Copiloto:public tripulacion{
public:
    Copiloto(string,string);
    virtual void Vuelo(Transbordador *,int);
    void Despegar(Transbordador);
    void Aterrizar(Transbordador);

};

class Piloto:public Copiloto{
public:
    Piloto(string,string);
    void Vuelo(Transbordador *,int,int);
};

#endif // TRIPULACION_H
